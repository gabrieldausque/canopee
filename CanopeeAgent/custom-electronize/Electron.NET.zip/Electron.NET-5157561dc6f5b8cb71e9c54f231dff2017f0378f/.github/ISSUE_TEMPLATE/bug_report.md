---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

<!-- Please search existing issues to avoid creating duplicates. -->

<!-- Which version of Electron.NET CLI and API are you using? -->
<!-- Please always try to use latest version before report. -->
* **Version**: 

<!-- Which version of .NET Core and Node.js are you using (if applicable)? -->

<!-- What target are you building for? -->
* **Target**: 

<!-- Enter your issue details below this comment. -->
<!-- If you want, you can donate to increase issue priority (https://donorbox.org/electron-net) -->

Steps to Reproduce:

1.
2.
