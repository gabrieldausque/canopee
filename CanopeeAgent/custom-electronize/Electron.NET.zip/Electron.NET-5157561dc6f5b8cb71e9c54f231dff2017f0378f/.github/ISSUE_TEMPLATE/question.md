---
name: Question
about: The issue tracker is not for questions. Please ask questions on https://stackoverflow.com/questions/tagged/electron.net
  or via chat in https://gitter.im/ElectronNET/community.
title: ''
labels: question
assignees: ''

---

🚨 The issue tracker is not for questions 🚨

The issue tracker is not for questions. Please ask questions on https://stackoverflow.com/questions/tagged/electron.net or via chat in https://gitter.im/ElectronNET/community.
