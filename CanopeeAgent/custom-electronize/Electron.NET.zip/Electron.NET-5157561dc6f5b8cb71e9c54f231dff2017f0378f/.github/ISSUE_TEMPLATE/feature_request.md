---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: Feature
assignees: ''

---

<!-- Please search existing feature request to avoid creating duplicates. -->

<!-- If you want, you can donate to increase feature request priority (https://donorbox.org/electron-net) -->
<!-- Describe the feature you'd like. -->
