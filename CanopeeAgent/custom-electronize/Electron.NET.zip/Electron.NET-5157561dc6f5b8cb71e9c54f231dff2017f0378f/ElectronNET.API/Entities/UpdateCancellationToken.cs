﻿namespace ElectronNET.API.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateCancellationToken
    {
        /// <summary>
        /// 
        /// </summary>
        public bool Cancelled { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public void Cancel()
        {

        }

        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {

        }
    }
}
