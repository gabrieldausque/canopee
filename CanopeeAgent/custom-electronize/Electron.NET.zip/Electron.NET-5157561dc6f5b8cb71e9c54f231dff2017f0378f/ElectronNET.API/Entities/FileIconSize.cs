﻿namespace ElectronNET.API.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public enum FileIconSize
    {
        /// <summary>
        /// The small
        /// </summary>
        small,

        /// <summary>
        /// The normal
        /// </summary>
        normal,

        /// <summary>
        /// The large
        /// </summary>
        large
    }
}