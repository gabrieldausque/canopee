﻿namespace ElectronNET.API.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateFileInfo : BlockMapDataHolder
    {
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }
    }
}
