﻿namespace ElectronNET.API
{
    /// <summary>
    /// 
    /// </summary>
    public enum DockBounceType
    {
        /// <summary>
        /// The critical
        /// </summary>
        critical,

        /// <summary>
        /// The informational
        /// </summary>
        informational
    }
}