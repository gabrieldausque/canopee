﻿namespace ElectronNET.API.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public class Error
    {
        /// <summary>
        /// Gets or sets the stack.
        /// </summary>
        /// <value>
        /// The stack.
        /// </value>
        public string Stack { get; set; }
    }
}