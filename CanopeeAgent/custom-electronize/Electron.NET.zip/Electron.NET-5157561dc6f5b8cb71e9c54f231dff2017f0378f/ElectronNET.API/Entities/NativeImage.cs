﻿namespace ElectronNET.API.Entities
{
    // TODO: Need some of real code :)
    /// <summary>
    /// 
    /// </summary>
    public class NativeImage
    {
        //        public static NativeImage CreateEmpty()
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public static NativeImage CreateFromBuffer(byte[] buffer)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public static NativeImage CreateFromBuffer(byte[] buffer, CreateFromBufferOptions options)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public static NativeImage CreateFromDataURL(string dataURL)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public static NativeImage CreateFromPath(string path)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public void AddRepresentation(AddRepresentationOptions options)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public NativeImage Crop(Rectangle rect)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public int GetAspectRatio()
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public byte[] GetBitmap()
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public byte[] GetBitmap(BitmapOptions options)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public byte[] GetNativeHandle()
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public Size GetSize()
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public bool IsEmpty()
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public bool IsTemplateImage()
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public NativeImage Resize(ResizeOptions options)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public void SetTemplateImage(bool option)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public byte[] ToBitmap(ToBitmapOptions options)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public string ToDataURL(ToDataURLOptions options)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public byte[] ToJPEG(int quality)
        //        {
        //            throw new NotImplementedException();
        //        }

        //        public byte[] ToPNG(ToPNGOptions options)
        //        {
        //            throw new NotImplementedException();
        //        }
    }
}
