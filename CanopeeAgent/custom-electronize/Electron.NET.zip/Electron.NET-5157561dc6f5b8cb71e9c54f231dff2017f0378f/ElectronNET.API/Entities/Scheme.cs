﻿namespace ElectronNET.API.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public enum Scheme
    {
        /// <summary>
        /// 
        /// </summary>
        basic,

        /// <summary>
        /// 
        /// </summary>
        digest,

        /// <summary>
        /// 
        /// </summary>
        ntlm,

        /// <summary>
        /// 
        /// </summary>
        negotiate
    }
}