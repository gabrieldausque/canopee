﻿namespace ElectronNET.API.Entities
{
    /// <summary>
    /// 
    /// </summary>
    public class ReleaseNoteInfo
    {
        /// <summary>
        /// The version.
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// The note.
        /// </summary>
        public string Note { get; set; }
    }
}
