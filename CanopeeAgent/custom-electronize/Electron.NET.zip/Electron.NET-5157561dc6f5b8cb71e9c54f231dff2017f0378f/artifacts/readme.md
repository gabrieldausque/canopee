Dummy file to ensure this directory is available after cloning
